
package com.owners.gravitas.business.impl;

import com.owners.gravitas.business.AgentReponseBusinessService;

/**
 * The Class AgentReponseBusinessServiceImpl.
 *
 * @author raviz
 */
public class AgentReponseBusinessServiceImpl implements AgentReponseBusinessService {

    /*
     * (non-Javadoc)
     * @see com.owners.gravitas.business.AgentReponseBusinessService#
     * syncAgentsResponseTime()
     */
    @Override
    public void syncAgentsResponseTime() {

    }

}
