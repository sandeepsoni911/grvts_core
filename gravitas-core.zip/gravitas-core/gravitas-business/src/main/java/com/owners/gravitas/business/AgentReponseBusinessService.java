package com.owners.gravitas.business;

/**
 * The Interface AgentReponseBusinessService.
 *
 * @author raviz
 */
public interface AgentReponseBusinessService {

    void syncAgentsResponseTime();
}
