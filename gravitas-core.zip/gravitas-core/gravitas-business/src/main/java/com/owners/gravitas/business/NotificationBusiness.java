package com.owners.gravitas.business;
/**
 * The NotificationBusiness interface
 * @author sandeepsoni
 *
 */
public interface NotificationBusiness {

	
	/**
	 * To process pending notifications
	 */
	public void processPendingNotifications();
}
