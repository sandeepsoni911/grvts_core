package com.owners.gravitas.business;


public interface ActivitiBusinessService {

	String findLatestExecutionId(String procInstanceId);
}
